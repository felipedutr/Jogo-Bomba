//PEDRO VINICIUS DA SULVA   2019005883
//FELIPE DE DUTRA SOUZA     2019013590

#include "pic18f4520.h"
#include "config.h"
#include "teclado.h"
#include "lcd.h"
#include "delay.h"

unsigned int atrasoMin = 20;
unsigned int atrasoMed = 500;
unsigned int atrasoMax = 1000;

int values7seg[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x67};
int cont = 60, i = 0;

void tempo(int t) {
    volatile unsigned char j, k;
    volatile unsigned int i;

    for (i = 0; i < (t * 10); i++) {
        for (j = 0; j < 41; j++) {
            for (k = 0; k < 3; k++);
        }
    }
}

void pararContagem(){
    BitClr(PORTA, 5);      
    BitClr(PORTA, 4); //desliga o 2o display
    BitClr(PORTA, 3); //desliga o 3o display
    BitClr(PORTA, 2); //desliga o 4o display 
}

void iniciarContagem()
{
    BitClr(INTCON2, 7);     //liga pull up 
    ADCON1  = 0x0E;         //config AD 
    TRISA   = 0x00;         //config da porta A 
    TRISD   = 0x00;         //config. a porta D - SAIDA
    PORTD   = 0x00;         //config. a porta D
    TRISB   = 0x00;         //config. a porta B - SAIDA
    PORTB   = 0x00;         //config. a porta B

    while(cont>0) {
        for (i = 0; i < 10; i++) {
            PORTD = values7seg[(cont / 1) % 10];
            BitSet(PORTA, 5); //liga o 1o display     
            BitClr(PORTA, 4); //desliga o 2o display
            BitClr(PORTA, 3); //desliga o 3o display
            BitClr(PORTA, 2); //desliga o 4o display 
                   tempo(1);
            PORTD = values7seg[(cont / 10) % 10];
            BitClr(PORTA, 5);     
            BitSet(PORTA, 4); 
            BitClr(PORTA, 3); 
            BitClr(PORTA, 2);  
                   tempo(1);
            PORTD = values7seg[(cont / 100) %10];
            BitClr(PORTA, 5);     
            BitClr(PORTA, 4); 
            BitSet(PORTA, 3); 
            BitClr(PORTA, 2); 
                   tempo(1);
            PORTD = values7seg[(cont / 1000) % 10];
            BitClr(PORTA, 5);    
            BitClr(PORTA, 4); 
            BitClr(PORTA, 3); 
            BitSet(PORTA, 2); 
            tempo(1);
        }cont--;
        
        if (cont == 0) {
            pararContagem();
        }
    }
}

void main(void) {
    unsigned char i=0, j=0;
    unsigned char tmp;
    char senha[4]= {'4','5','2','0'};
    char lido[4];
 
    ADCON1 = 0x06;
    TRISB = 0x01;
    TRISD = 0x00;
    TRISE = 0x00;
    
    lcd_init();
    
    
    //Teclado num�rico
    TRISB = 0xF8;

    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("FAMILIA PIC18F");
    lcd_cmd(L_L2);
    
    iniciarContagem();
    
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("DESARME A BOMBA!");
    lcd_cmd(L_L2);
    
    while (1) {

        
        
        TRISD = 0x0F;
        tmp = tc_tecla(10000) + 0x30;
        TRISD = 0x00;
        lcd_dat(tmp);
        lido[i] = tmp;
        i++;
     
        if(i==4){
            for (i=0; i<4; i++)
            {
                if((senha[i] != lido[i]) /*|| (cont <= 0)*/)//senha errada
                {
                    lcd_cmd(L_CLR);
                    lcd_cmd(L_L1);
                    lcd_str("BOOOOOOOOOOOOOM!");
                    break; 
                }else
                if((senha[i] == lido[i]) && (i == 3)){
                    lcd_cmd(L_CLR);
                    lcd_cmd(L_L1);
                    lcd_str("BOMBA DESARMADA!");
                    break;
                }
            }
        }
    }
    for (i = 0; i < 16; i++) {
        lcd_cmd(L_CLR);
    }
    lcd_str("FIM DE JOGO!");
        
    return;
}
