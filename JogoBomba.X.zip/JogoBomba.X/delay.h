#ifndef DELAY_H
#define	DELAY_H

void atraso_ms(int t);

#endif	